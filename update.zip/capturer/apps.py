from django.apps import AppConfig


class CaputurerConfig(AppConfig):
    name = 'caputurer'
